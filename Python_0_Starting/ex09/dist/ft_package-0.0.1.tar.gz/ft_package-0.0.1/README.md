Exercice about creation of a python package

etap 1 create new file "__init.py__" -> python consider it's a package

etap 2 create a setup.py 